const database = require('../utils/database');

exports.getCategories = async () => {
  const [rows, fields] = await database.execute(`SELECT * FROM categories`);
  return rows;
}

exports.getRestaurantsByCategory = async (category) => {
  const [rows, fields] = await database.execute(`SELECT * FROM restaurants WHERE category="${category}" ORDER BY stars DESC`);
  return rows;
}

exports.addCategory = async (category, image) => {
  return database.execute('INSERT INTO categories VALUES (?, ?)', [category, image]);
}

exports.addRestaurant = async ({ name, description, stars, price, city, category }, image) => {
  return database.execute(`INSERT INTO restaurants (name, description, stars, price, city, category, image) VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [name, description, stars, price, city, category, image]);
}