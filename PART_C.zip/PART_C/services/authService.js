const bycrypt = require('bcryptjs');
const database = require('../utils/database');

exports.createUser = async ({ firstName, lastName, email, gender, password }) => {
  const hashedPassword = await bycrypt.hash(password, 12);
  database.query('INSERT INTO users (firstName, lastName, email, gender, password) VALUES (?, ?, ?, ?, ?)',
    [firstName, lastName, email, gender, hashedPassword]).then(() => {
      console.log("User created");
    })
    .catch((err) => {
      if (err.errno === 1062) {
        console.log("User already exists");
      }

      return res.sendStatus(500);
    });
}

exports.getUser = async ({ email, password }) => {
  const [rows, field] = await database.query('SELECT * FROM users WHERE email=?', [email]);
  const isMatch = rows.length > 0 ? await bycrypt.compare(password, rows[0].password) : false;
  return isMatch ? rows[0] : null;
}