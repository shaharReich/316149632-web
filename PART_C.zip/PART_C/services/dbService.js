const database = require('../utils/database');

exports.createDB = () => {
  return Promise.all([
    this.createUsersTable(),
    this.createCategoryTable(),
    this.createRestaurantsTable()
  ])
}

exports.insertData = () => {
  return Promise.all([
    this.insertCategoriesData(),
    this.insertRestaurantsData(),
  ])
}

exports.dropDB = () => {
  return Promise.all([
    dropTable('users'),
    dropTable('categories'),
    dropTable('restaurants')
  ])
}

const dropTable = (tableName) => {
  return database.execute(`DROP TABLE IF EXISTS ${tableName}`);
}

exports.createUsersTable = () => {
  const usersTableSchema = `CREATE TABLE IF NOT EXISTS users (
    id INT NOT NULL AUTO_INCREMENT,
    firstName VARCHAR(255) NULL,
    lastName VARCHAR(255) NULL,
    email VARCHAR(255) NULL,
    gender VARCHAR(255) NULL,
    password VARCHAR(255) NULL,
    PRIMARY KEY (id),
    UNIQUE INDEX email_UNIQUE (email ASC) VISIBLE)`;

  return database.execute(usersTableSchema);
}

exports.createCategoryTable = () => {
  const categoryTableSchema = `CREATE TABLE IF NOT EXISTS categories (
    name VARCHAR(255) NOT NULL,
    image VARCHAR(255) NULL,
    PRIMARY KEY (name))`;

  return database.execute(categoryTableSchema);
}

exports.createRestaurantsTable = () => {
  const restaurantsTableSchema = `CREATE TABLE IF NOT EXISTS restaurants (
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(255) NULL,
    description VARCHAR(255) NULL,
    stars DECIMAL(10,1) NULL,
    image VARCHAR(255) NULL,
    price INT NULL,
    city VARCHAR(255) NULL,
    category VARCHAR(255) NOT NULL,
    PRIMARY KEY (id))`;
  
  return database.execute(restaurantsTableSchema);
}

exports.selectTable = async (tableName) => {
  const [rows, fields] = await database.execute(`SELECT * FROM ${tableName}`);
  return rows;
}

exports.insertCategoriesData = () => {
  const query = `INSERT INTO categories (name, image) VALUES
    ("Vegan", "/images/vegan.png"),
    ("Gluten Free", "/images/gluten-free.png"),
    ("Dairy Free", "/images/dairy-free.png"),
    ("Sugar Free", "/images/sugar-free.png")`;

    return database.execute(query);
}

exports.insertRestaurantsData = () => {
  const query = `INSERT INTO restaurants (name, description, stars, image, price, city, category) VALUES
    ("Le Jardin Francais", "A charming French bistro offering traditional cuisine in a cozy garden setting.", 4, "/images/restEx.jpg" ,2, "Paris", "Gluten Free"),
    ("The Spicy Kitchen", "An eclectic Indian restaurant serving a range of fiery dishes in a vibrant atmosphere.", 3, "/images/restEx.jpg", 1, "London", "Sugar Free"),
    ("Seafood Paradise", "A seafood lover's paradise featuring fresh catches and exotic seafood dishes in a stylish setting.", 5, "/images/restEx.jpg", 3, "New York", "Gluten Free")`;

    return database.execute(query);
}