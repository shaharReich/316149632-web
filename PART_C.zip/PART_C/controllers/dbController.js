const dbService = require('../services/dbService');

exports.createDB = async (req, res, next) => {
  try {
    await dbService.createDB();
  } catch (e) {
    console.log("Something wrong, failed to create tables", e);
    return res.sendStatus(500);
  }
  return res.sendStatus(200);
}

exports.dropDB = async (req, res, next) =>{
  try {
    await dbService.dropDB();
  } catch (e) {
    console.log("Something wrong, failed to drop tables", e);
    return res.sendStatus(500);
  }
  return res.sendStatus(200);
}

exports.insertData = async (req, res, next) =>{
  try {
    await dbService.insertData();
  } catch (e) {
    console.log("Something wrong, failed to insert data", e);
    return res.sendStatus(500);
  }
  return res.sendStatus(200);
}

exports.selectTable = async (req, res, next) => {
  try {
    const rows = await dbService.selectTable(req.params.tableName);
    return res.json(rows);
  } catch (e) {
    return res.sendStatus(404);
  }
}