const dashboardService = require('../services/dashboardService');

exports.preferences = async (req, res, next) => {
  const categories = await dashboardService.getCategories();
  return res.render("preferences", { categories: categories });
}

exports.restaurantsSingle = async (req, res, next) => {
  const category = req.params.category
  const restaurants = await dashboardService.getRestaurantsByCategory(category);
  return res.render("restaurantSinglePage", { restaurants: restaurants, category: category });
}

exports.addRestaurant = async (req, res, next) => {
  await dashboardService.addRestaurant(req.body, "/images/" + req.file.filename);
  return this.restaurantsSingle(req, res, next);
}


exports.addCategory = async (req, res, next) => {
  await dashboardService.addCategory(req.body.name, "/images/" + req.file.filename);
  return this.preferences(req, res, next);
}
