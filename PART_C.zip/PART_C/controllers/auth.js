const authService = require('../services/authService');

exports.loginPage = (req, res, next) => {
    res.render('login');
}

exports.registerPage = (req, res, next) => {
  return res.render('register');
}

exports.registerPost = async (req, res, next) => {
  await authService.createUser(req.body);
  return res.render('login');
}

exports.loginPost = async (req, res, next) => {
  console.log("req.body", req.body);
  const user = await authService.getUser(req.body);
  if (user) {
    req.session.user = {
      id: user.id,
      name: `${user.firstName} ${user.lastName}`
    }
    req.session.isUserIn = true;
    res.locals.name = `${user.firstName} ${user.lastName}`;
    return res.redirect("preferences");
  }

  return res.render("login");
}

failLogin = (res) => {
  res.status(422).render('login');
}

exports.logout = async (req, res, next) => {
  try {
    await req.session.destroy();
  }
  catch (e) {
    console.log(e);
  }
  res.redirect('/');
}
