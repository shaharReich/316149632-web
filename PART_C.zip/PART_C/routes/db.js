const router = require('express').Router();

const createDB = require('../controllers/dbController');

router.get('/createDB', createDB.createDB);
router.get('/dropDB', createDB.dropDB);
router.get('/insertData', createDB.insertData);
router.get('/select/:tableName', createDB.selectTable);

module.exports = router;
