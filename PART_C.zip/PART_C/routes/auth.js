const router = require('express').Router();

const isAuth = require('../middleware/isAuth');

const loginController = require('../controllers/auth');

router.post('/', loginController.loginPost);
router.get('/' , loginController.loginPage);
router.get('/register', loginController.registerPage);
router.post('/register', loginController.registerPost);

router.get('/logout', isAuth, loginController.logout);

module.exports = router;
