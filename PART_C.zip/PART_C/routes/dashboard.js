const router = require('express').Router();

const isAuth = require('../middleware/isAuth');

const dashboardController = require('../controllers/dashboard');
const multer  = require('multer')
const fileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './public/images');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '' + file.originalname);
  }
})

const upload = multer({ storage: fileStorage });

router.get('/preferences', isAuth, dashboardController.preferences);
router.post('/addCategory', isAuth, upload.single('image'), dashboardController.addCategory);
router.post('/addRestaurant', isAuth, upload.single('image'), dashboardController.addRestaurant);

router.get('/restaurants/:category', isAuth, dashboardController.restaurantsSingle);

module.exports = router;
