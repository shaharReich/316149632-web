const mysql = require('mysql2');
const dbConfig = require('../configurations/db.config');

const pool = mysql.createPool({
  ...dbConfig,
  waitForConnections: true,
  queueLimit: 0,
  charset: "utf8mb4"
});

module.exports = pool.promise();
