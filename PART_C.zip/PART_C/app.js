const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const session = require('express-session');
const MySQLStore = require('express-mysql-session')(session); // Save sessions on database

const app = express();

const sessionStore = new MySQLStore({ schema: { tableName: 'knowme_session' } }, require('./utils/database')); // Connect session to database
app.use(session({
  key: 'session_cookie_name',
  secret: 'my_secret code',
  store: sessionStore,
  resave: false,
  saveUninitialized: false
}));

app.set('view engine', 'ejs');
app.set('views', 'views');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

const auth = require('./routes/auth');
const dashboard = require('./routes/dashboard');
const db = require('./routes/db');

app.use(auth);
app.use(db);
app.use(dashboard);

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server ready at ${port} 🚀`);
})
