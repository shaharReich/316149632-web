module.exports = (req, res, next) => {
  if (req.session.isUserIn) {
      res.locals.name = req.session.user.name;
      next();
  }
  else {
      res.redirect('/');
  }
}